<?php
require('fpdf.php');

// Database connection
$db = new mysqli('localhost', 'root', '', 'hospital_management');
if ($db->connect_error) {
    die('Connection failed: ' . $db->connect_error);
}

// Get bill ID
if (isset($_GET['bill_id'])) {
    $bill_id = intval($_GET['bill_id']);
    $query = "SELECT * FROM billing WHERE bill_id = $bill_id"; // make sure table name is correct
    $result = $db->query($query);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Generate PDF
        $pdf = new FPDF();
        $pdf->AddPage();

        // Title
        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(0, 10, 'Billing Details', 0, 1, 'C');
        $pdf->Ln(10);

        // Table rows
        $pdf->SetFont('Arial', '', 12);
        foreach ($row as $key => $value) {
            $pdf->Cell(50, 10, ucfirst(str_replace("_", " ", $key)) . ":", 1, 0);
            $pdf->Cell(0, 10, $value, 1, 1);
        }

        // Output to browser
        $pdf->Output();
    } else {
        echo "No billing found with ID $bill_id";
    }
} else {
    echo "No bill ID provided.";
}
?>