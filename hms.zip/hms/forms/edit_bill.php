<?php
include 'connect.php';

$id = $_GET['id'] ?? null;
if (!$id) {
    die("No ID provided.");
}

// Correct table name is billing
$sql = "SELECT * FROM billing WHERE bill_id = $id";
$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

$bill = $result->fetch_assoc();
if (!$bill) {
    die("No bill found with ID $id");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bill_date = $_POST['bill_date'];
    $payment_status = $_POST['payment_status'];
    $total_amount = $_POST['total_amount'];

    $update_sql = "UPDATE billing 
                   SET bill_date='$bill_date', 
                       payment_status='$payment_status', 
                       total_amount='$total_amount' 
                   WHERE bill_id = $id";

    if ($conn->query($update_sql)) {
        header("Location: billing.php");
        exit;
    } else {
        die("Update failed: " . $conn->error);
    }
}
?>
<form method="post">
    Bill ID: <input type="text" value="<?= $bill['bill_id'] ?>" readonly><br>
    Patient ID: <input type="text" value="<?= $bill['patient_id'] ?>" readonly><br>
    
    Bill Date: <input type="date" name="bill_date" value="<?= $bill['bill_date'] ?>"><br>
    
    Payment Status:
    <select name="payment_status">
        <option <?= $bill['payment_status'] == 'Paid' ? 'selected' : '' ?>>Paid</option>
        <option <?= $bill['payment_status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
    </select><br>
    
    Total Amount: <input type="number" step="0.01" name="total_amount" value="<?= $bill['total_amount'] ?>"><br>
    
    <button type="submit">Save Changes</button>
</form>