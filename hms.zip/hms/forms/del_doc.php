<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "hospital_management");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if doctor_id is provided
if (isset($_GET['doctor_id'])) {
    $doctor_id = intval($_GET['doctor_id']); // prevent SQL injection

    // Delete query
    $sql = "DELETE FROM doctors WHERE doctor_id = $doctor_id";

    if ($conn->query($sql) === TRUE) {
        header("Location: doctor.php"); // redirect to doctors list
        exit;
    } else {
        echo "Error deleting doctor: " . $conn->error;
    }
} else {
    echo "No doctor ID provided.";
}

$conn->close();
?>