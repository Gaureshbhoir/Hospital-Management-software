<?php
include 'connect.php';

if (!isset($_GET['record_id'])) {
    die("ID not provided.");
}

$id = $_GET['record_id'];
$sql = "SELECT * FROM medical_records WHERE record_id = $id";
$result = mysqli_query($conn, $sql);

if (!$result || mysqli_num_rows($result) == 0) {
    die("Record not found.");
}

$row = mysqli_fetch_assoc($result);

if (isset($_POST['update'])) {
    $patient_id = $_POST['patient_id'];
    $doctor_id = $_POST['doctor_id'];
    $diagnosis = $_POST['diagnosis'];
    $treatment = $_POST['treatment'];
    $record_date = $_POST['record_date'];

    $update_sql = "UPDATE medical_records 
                   SET patient_id='$patient_id', doctor_id='$doctor_id', diagnosis='$diagnosis', 
                       treatment='$treatment', record_date='$record_date'
                   WHERE record_id = $id";

    if (mysqli_query($conn, $update_sql)) {
        header("Location: record.php");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Medical Record</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="p-4">
    <h2>Edit Medical Record</h2>
    <form method="POST">
        <div class="mb-3">
            <label>Patient ID</label>
            <input type="text" name="patient_id" class="form-control" value="<?php echo $row['patient_id']; ?>" required>
        </div>
        <div class="mb-3">
            <label>Doctor ID</label>
            <input type="text" name="doctor_id" class="form-control" value="<?php echo $row['doctor_id']; ?>" required>
        </div>
        <div class="mb-3">
            <label>Diagnosis</label>
            <input type="text" name="diagnosis" class="form-control" value="<?php echo $row['diagnosis']; ?>" required>
        </div>
        <div class="mb-3">
            <label>Treatment</label>
            <input type="text" name="treatment" class="form-control" value="<?php echo $row['treatment']; ?>" required>
        </div>
        <div class="mb-3">
            <label>Record Date</label>
            <input type="date" name="record_date" class="form-control" value="<?php echo $row['record_date']; ?>" required>
        </div>
        <button type="submit" name="update" class="btn btn-success">Update</button>
        <a href="medical_records.php" class="btn btn-secondary">Cancel</a>
    </form>
</body>
</html>