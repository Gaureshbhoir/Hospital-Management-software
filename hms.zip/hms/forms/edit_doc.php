<?php
$conn = new mysqli("localhost", "root", "", "hospital_management");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['doctor_id'])) {
    $doctor_id = $_GET['doctor_id'];

    // Fetch doctor details
    $result = $conn->query("SELECT * FROM doctors WHERE doctor_id = $doctor_id");
    $doctor = $result->fetch_assoc();
}

if (isset($_POST['update'])) {
    $name = $_POST['name'];
    $specialization = $_POST['specialization'];
    $contact_number = $_POST['contact_number'];
    $email = $_POST['email'];

    $sql = "UPDATE doctors SET 
            name='$name', 
            specialization='$specialization', 
            contact_number='$contact_number', 
            email='$email' 
            WHERE doctor_id=$doctor_id";

    if ($conn->query($sql) === TRUE) {
        header("Location: doctor.php");
        exit;
    } else {
        echo "Error updating doctor: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Doctor</title>
</head>
<body>
    <h2>Edit Doctor Details</h2>
    <form method="post">
        Name: <input type="text" name="name" value="<?= $doctor['name'] ?>"><br>
        Specialization: <input type="text" name="specialization" value="<?= $doctor['specialization'] ?>"><br>
        Contact Number: <input type="text" name="contact_number" value="<?= $doctor['contact_number'] ?>"><br>
        Email: <input type="email" name="email" value="<?= $doctor['email'] ?>"><br>
        <button type="submit" name="update">Update</button>
    </form>
</body>
</html>