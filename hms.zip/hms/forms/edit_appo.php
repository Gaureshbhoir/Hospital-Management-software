<?php
include 'connect.php';

if (!isset($_GET['id'])) {
    die("ID not provided.");
}

$id = $_GET['id'];
$sql = "SELECT * FROM appointments WHERE appointment_id = $id";
$result = mysqli_query($conn, $sql);

if (!$result || mysqli_num_rows($result) == 0) {
    die("Appointment not found.");
}

$row = mysqli_fetch_assoc($result);

if (isset($_POST['update'])) {
    $patient_id = $_POST['patient_id'];
    $doctor_id = $_POST['doctor_id'];
    $appointment_date = $_POST['appointment_date'];
    $status = $_POST['status'];

    $update_sql = "UPDATE appointments 
                   SET patient_id='$patient_id', doctor_id='$doctor_id', 
                       appointment_date='$appointment_date', status='$status'
                   WHERE appointment_id = $id";

    if (mysqli_query($conn, $update_sql)) {
        header("Location: appointment.php");
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Appointment</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="p-4">
    <h2>Edit Appointment</h2>
    <form method="POST">
        <div class="mb-3">
            <label>Patient ID</label>
            <input type="text" name="patient_id" class="form-control" value="<?php echo $row['patient_id']; ?>" required>
        </div>
        <div class="mb-3">
            <label>Doctor ID</label>
            <input type="text" name="doctor_id" class="form-control" value="<?php echo $row['doctor_id']; ?>" required>
        </div>
        <div class="mb-3">
            <label>Appointment Date</label>
            <input type="datetime-local" name="appointment_date" class="form-control" 
                   value="<?php echo date('Y-m-d\TH:i', strtotime($row['appointment_date'])); ?>" required>
        </div>
        <div class="mb-3">
            <label>Status</label>
            <select name="status" class="form-control" required>
                <option value="Scheduled" <?php if($row['status']=="Scheduled") echo "selected"; ?>>Scheduled</option>
                <option value="Completed" <?php if($row['status']=="Completed") echo "selected"; ?>>Completed</option>
                <option value="Cancelled" <?php if($row['status']=="Cancelled") echo "selected"; ?>>Cancelled</option>
            </select>
        </div>
        <button type="submit" name="update" class="btn btn-success">Update</button>
        <a href="appointments.php" class="btn btn-secondary">Cancel</a>
    </form>
</body>
</html>