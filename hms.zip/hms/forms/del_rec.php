<?php
include 'connect.php';

if (!isset($_GET['record_id'])) {
    die("ID not provided.");
}

$id = $_GET['record_id'];

$sql = "DELETE FROM medical_records WHERE record_id = $id";

if (mysqli_query($conn, $sql)) {
    header("Location: record.php");
    exit;
} else {
    echo "Error: " . mysqli_error($conn);
}
?>