<?php
include 'connect.php';

if (!isset($_GET['id'])) {
    die("ID not provided.");
}

$id = $_GET['id'];

$sql = "DELETE FROM billing WHERE bill_id = $id";

if (mysqli_query($conn, $sql)) {
    header("Location: billing.php");
    exit;
} else {
    echo "Error: " . mysqli_error($conn);
}
?>