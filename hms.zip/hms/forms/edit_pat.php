<?php
$conn = new mysqli("localhost", "root", "", "hospital_management");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_GET['id'])) {
    die("No patient ID provided.");
}

$id = intval($_GET['id']);

// Fetch patient data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $contact = $_POST['contact_number'];
    $address = $_POST['address'];
    $blood = $_POST['blood_group'];

    $sql = "UPDATE patients SET name='$name', gender='$gender', dob='$dob', contact_number='$contact', address='$address', blood_group='$blood' WHERE patient_id=$id";
    if ($conn->query($sql)) {
        header("Location: patient.php");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

$result = $conn->query("SELECT * FROM patients WHERE patient_id=$id");
if ($result->num_rows === 0) {
    die("Patient not found.");
}
$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head><title>Edit Patient</title></head>
<body>
<h2>Edit Patient</h2>
<form method="POST">
    Name: <input type="text" name="name" value="<?= $row['name'] ?>" required><br>
    Gender: 
    <select name="gender">
        <option value="Male" <?= $row['gender']=="Male"?"selected":"" ?>>Male</option>
        <option value="Female" <?= $row['gender']=="Female"?"selected":"" ?>>Female</option>
        <option value="Other" <?= $row['gender']=="Other"?"selected":"" ?>>Other</option>
    </select><br>
    DOB: <input type="date" name="dob" value="<?= $row['dob'] ?>" required><br>
    Contact: <input type="text" name="contact_number" value="<?= $row['contact_number'] ?>"><br>
    Address: <input type="text" name="address" value="<?= $row['address'] ?>"><br>
    Blood Group: <input type="text" name="blood_group" value="<?= $row['blood_group'] ?>"><br>
    <button type="submit">Update</button>
</form>
</body>
</html>