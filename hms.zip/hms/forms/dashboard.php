<?php
// --- Database Connection ---
$host = "localhost";
$user = "root";   // change if needed
$pass = "";       // change if needed
$db   = "hospital_management";

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// ---- Billing Data (last 7 entries) ----
$billingQuery = "SELECT bill_date, total_amount FROM billing ORDER BY bill_date DESC LIMIT 7";
$billingResult = mysqli_query($conn, $billingQuery);

$billingLabels = [];
$billingAmounts = [];
while ($row = mysqli_fetch_assoc($billingResult)) {
    $billingLabels[] = $row['bill_date'];
    $billingAmounts[] = (float)$row['total_amount'];
}

// ---- Patient Gender Data ----
$genderQuery = "SELECT gender, COUNT(*) as count FROM patients GROUP BY gender";
$genderResult = mysqli_query($conn, $genderQuery);

$male = $female = $other = 0;
while ($row = mysqli_fetch_assoc($genderResult)) {
    if (strtolower($row['gender']) == 'male') $male = $row['count'];
    elseif (strtolower($row['gender']) == 'female') $female = $row['count'];
    else $other = $row['count'];
}

// ---- Appointments by Doctor ----
$appQuery = "SELECT d.name as doctor_name, COUNT(*) as count 
             FROM appointments a 
             JOIN doctors d ON a.doctor_id = d.doctor_id 
             GROUP BY a.doctor_id";
$appResult = mysqli_query($conn, $appQuery);

$doctorNames = [];
$appointmentCounts = [];
while ($row = mysqli_fetch_assoc($appResult)) {
    $doctorNames[] = $row['doctor_name'];
    $appointmentCounts[] = $row['count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hospital Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body { background: #f8f9fa; }
    .chart-card {
      padding: 15px;
      border-radius: 15px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      background: #fff;
      margin-bottom: 20px;
    }
    canvas {
      max-height: 300px !important;
    }
  </style>
</head>
<body>

<div class="container py-4">
  <h2 class="text-center mb-4">🏥 Hospital Dashboard</h2>
  <div class="row g-4">
    
    <!-- Line Chart -->
    <div class="col-md-6">
      <div class="chart-card">
        <h5 class="text-center">Billing Trends</h5>
        <canvas id="lineChart"></canvas>
      </div>
    </div>
    
    <!-- Pie Chart -->
    <div class="col-md-6">
      <div class="chart-card">
        <h5 class="text-center">Patient Gender</h5>
        <canvas id="pieChart"></canvas>
      </div>
    </div>
    
    <!-- Bar Chart -->
    <div class="col-md-12">
      <div class="chart-card">
        <h5 class="text-center">Appointments by Doctor</h5>
        <canvas id="barChart"></canvas>
      </div>
    </div>
    
  </div>
</div>

<script>
  // --- Billing Line Chart ---
  new Chart(document.getElementById("lineChart"), {
    type: "line",
    data: {
      labels: <?php echo json_encode(array_reverse($billingLabels)); ?>,
      datasets: [{
        label: "Revenue",
        data: <?php echo json_encode(array_reverse($billingAmounts)); ?>,
        borderColor: "red",
        backgroundColor: "rgba(255,0,0,0.2)",
        fill: true,
        tension: 0.4
      }]
    }
  });

  // --- Patient Gender Pie Chart ---
  new Chart(document.getElementById("pieChart"), {
    type: "pie",
    data: {
      labels: ["Male", "Female", "Other"],
      datasets: [{
        data: [<?php echo $male; ?>, <?php echo $female; ?>, <?php echo $other; ?>],
        backgroundColor: ["#007bff", "#dc3545", "#ffc107"]
      }]
    }
  });

  // --- Appointments by Doctor Bar Chart ---
  new Chart(document.getElementById("barChart"), {
    type: "bar",
    data: {
      labels: <?php echo json_encode($doctorNames); ?>,
      datasets: [{
        label: "Appointments",
        data: <?php echo json_encode($appointmentCounts); ?>,
        backgroundColor: "#0d6efd"
      }]
    },
    options: { plugins: { legend: { display: false } } }
  });
</script>

</body>
</html>