<?php
include 'connect.php';

if (!isset($_GET['id'])) {
    die("ID not provided.");
}

$id = $_GET['id'];

$sql = "DELETE FROM appointments WHERE appointment_id = $id";

if (mysqli_query($conn, $sql)) {
    header("Location: appointment.php");
    exit;
} else {
    echo "Error: " . mysqli_error($conn);
}
?>